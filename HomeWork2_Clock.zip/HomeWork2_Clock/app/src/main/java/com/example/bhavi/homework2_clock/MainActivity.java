package com.example.bhavi.homework2_clock;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.DatePicker;
import android.widget.DigitalClock;
import android.widget.TextView;
import android.widget.Toast;


import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

  private static final String TAG = "MainActivity";
  private TextView mDisplayDate ;
  private TextView dateView ;
  private TextView dateView1 ;
  private DatePickerDialog.OnDateSetListener mDateSetListener;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    mDisplayDate = (TextView) findViewById(R.id.textView);
    dateView = (TextView) findViewById(R.id.textView2);
    dateView1 = (TextView) findViewById(R.id.textView3);
    mDisplayDate.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dialog = new DatePickerDialog(MainActivity.this,
                android.R.style.Theme_Holo_Dialog_MinWidth,
                mDateSetListener, year, month, day);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
      }
    });

    mDateSetListener = new DatePickerDialog.OnDateSetListener() {
      @Override
      public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        month = month + 1;
        Log.d(TAG, "onDate: mm/dd/yyyy:" + month + "/" + dayOfMonth + "/" + year);
        String date = month + "/" + dayOfMonth + "/" + year;
        dateView.setText(date);
        dateView1.setText(date);
      }
    };
    Calendar calendar = Calendar.getInstance();
    SimpleDateFormat mdformat = new SimpleDateFormat("MMM d, yyyy");
    String strDate = mdformat.format(calendar.getTime());
    TextView textView = (TextView) findViewById(R.id.textView2);
    textView.setText(strDate);
    TextView textView1 = (TextView) findViewById(R.id.textView3);
    textView1.setText(strDate);
  }

}
